﻿namespace API_EF6.Models.Entities.Clientes
{
    public class PostClientes
    {
        public string Nome { get; set; }
        public DateTime Data_Nascimento { get; set; }
    }
}
