﻿namespace API_EF6.Models.Entities.Clientes
{
    public class ClienteId
    {
        public int Id { get; set; }
    }
}
