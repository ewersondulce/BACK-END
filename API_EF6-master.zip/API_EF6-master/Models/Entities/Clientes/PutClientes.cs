﻿namespace API_EF6.Models.Entities.Clientes
{
    public class PutClientes:PostClientes
    {
        public int id { get; set; }
    }
}
